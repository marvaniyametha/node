const mongoose = require('mongoose');

const dbconnect = () => {
    mongoose.connect('mongodb://localhost:27017/exam')
        .then(() => {
            console.log("database conected successfully");
        })
        .catch((err) => {
            console.log(err);
        })
}


module.exports = dbconnect;
